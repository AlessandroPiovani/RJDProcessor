  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
                                                       Stochastic Component: White Noise Residuals
                                                  Seasonal frequencies(cycles per year and TD freq.(rad.)
                                                 ----------------------------------------------
                                                  one    two    three  four   five   six    TD   
   1   "VATASA"                                   --     -T     --     --     --     --     -T
   2   "VATASC"                                   At     at     --     --     --     --     -t
   3   "VATAIA"                                   --     --     --     --     --     --     aT
   4   "VATPIA"                                   --     --     --     --     --     --     aT
   5   "VATPIC"                                   -t     -t     --     --     --     --     -T
   6   "VATPSC"                                   at     aT     --     --     --     --     --
   7   "VATAIC"                                   --     --     --     --     --     --     at
   8   "VATPSA"                                   --     at     --     --     --     --     --
 
 
 
 
 mq=12:  TD= 2.1878 rad 
 mq=4 :  TD= 0.2802 rad 
 
 AT : peaks detected in AR(30) and using Tukey spectrum estimator
 A- : only peaks detected in AR(30) spectrum estimator
 -T : only peaks detected using Tukey spectrum estimator
 -- : No peaks detected in AR(30) nor using Tukey spectrum estimator
