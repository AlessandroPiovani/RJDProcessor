  *** Seats Revision: 942  Build: 2017/09/25 09:48:03                                                            ***
   n   Title                                    Spectr.          Convergence (in %)                   Bias         Check   Check        Determ.
                                                Factor         1Y                 5Y                                                  Comp. Modif.
                                                          TC        SA        TC        SA        TC        SA     on ACF  on CCF    TC S U Trans SA
   1   "vatasa"                                   0      87.0      58.8      99.7      99.2      0.06      0.00      0       0        N Y Y     N  Y
   2   "vatasc"                                   0      77.6      74.9      99.9      99.9      0.09      0.00      0       0        Y Y Y     N  Y
   3   "vataia"                                   0      92.3      93.7     100.0     100.0      0.03      0.00      0       0        Y Y Y     N  Y
   4   "vatpia"                                   0      93.2      67.2      99.9      99.7      0.05      0.00      0       0        N Y Y     N  Y
   5   "vatpic"                                   0      92.8      75.6      99.7      99.9      0.09      0.00      0       0        N Y Y     N  Y
   6   "vatpsc"                                   0      84.4      76.1     100.0     100.0      0.07      0.00      0       0        N Y Y     N  Y
   7   "vataic"                                   0      95.6      99.8      99.9     100.0      0.06      0.00      0       0        N Y Y     N  Y
   8   "vatpsa"                                   0      72.2      48.0      98.2      96.7      0.14      0.00      0       0        N Y Y     N  Y
