  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
                                                       Stochastic Component: Original Series
                                                  Seasonal frequencies(cycles per year and TD freq.(rad.)
                                                 ----------------------------------------------
                                                  one    two    three  four   five   six    TD   
   1   "VATASA"                                   aT     -t     aT     -T     AT     a-     --
   2   "VATASC"                                   AT     aT     aT     -T     -T     aT     --
   3   "VATAIA"                                   AT     aT     -t     -t     -T     AT     -t
   4   "VATPIA"                                   AT     AT     aT     -t     aT     aT     -t
   5   "VATPIC"                                   AT     AT     AT     -T     aT     aT     -t
   6   "VATPSC"                                   AT     AT     aT     -T     aT     -t     --
   7   "VATAIC"                                   AT     AT     -T     -t     -t     AT     aT
   8   "VATPSA"                                   AT     aT     aT     AT     AT     a-     --
 
 
 
 
 mq=12:  TD= 2.1878 rad 
 mq=4 :  TD= 0.2802 rad 
 
 AT : peaks detected in AR(30) and using Tukey spectrum estimator
 A- : only peaks detected in AR(30) spectrum estimator
 -T : only peaks detected using Tukey spectrum estimator
 -- : No peaks detected in AR(30) nor using Tukey spectrum estimator
