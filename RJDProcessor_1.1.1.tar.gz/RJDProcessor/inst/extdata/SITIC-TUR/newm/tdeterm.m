  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
    n     TITLE                                          TD      EE    #OUT      AO      TC      LS      SO     REG DETseas
      1  "VATASA"                                         0       1      29      28       1       0       0       1   0
      2  "VATASC"                                         0       1      30      23       6       1       0       2   0
      3  "VATAIA"                                         0       1      24      23       0       1       0       7   0
      4  "VATPIA"                                         0       1      21      21       0       0       0       6   0
      5  "VATPIC"                                         0       1      14      13       1       0       0       6   0
      6  "VATPSC"                                         0       1      26      20       6       0       0       1   0
      7  "VATAIC"                                         0       1      16      16       0       0       0       7   0
      8  "VATPSA"                                         0       1      28      26       2       0       0       1   0
