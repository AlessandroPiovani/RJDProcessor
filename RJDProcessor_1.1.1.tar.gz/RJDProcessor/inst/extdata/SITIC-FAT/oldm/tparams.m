  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
   Input Parameters 
Serie     1
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   
   Reglist01
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      66     AO
      49     LS
 
Serie     2
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   
   Reglist01
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     183     AO
     184     AO
 
Serie     3
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   
   Reglist01
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     183     AO
     185     AO
     186     AO
     188     AO
 
Serie     4
   lam= 0   imean= 0   bq= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   
   Reglist01
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     183     AO
     185     AO
     147     AO
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 312
 
Serie     5
   lam= 1   imean= 0   d= 0   p= 1   q= 0   bq= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      57     AO
      51     LS
      37     AO
     183     AO
     184     AO
 
Serie     6
   lam= 1   imean= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     AO
      25     TC
     183     AO
     184     AO
     188     AO
 
Serie     7
   lam= 0   imean= 0   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
Serie     8
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      28     TC
       7     AO
     184     TC
 
Serie     9
   lam= 1   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      17     AO
      48     TC
      85     TC
     185     AO
     186     AO
     187     AO
     193     AO
 
Serie    10
   lam= 1   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      84     AO
      61     LS
     185     AO
     186     AO
 
Serie    11
   lam= 0   imean= 0   ireg= 1   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 1   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      61     LS
 
Serie    12
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      84     AO
      12     AO
     185     AO
     186     AO
 
Serie    13
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      50     LS
      86     AO
      99     AO
      36     AO
      61     LS
     131     AO
     183     AO
     184     AO
 
Serie    14
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      57     AO
     184     AO
 
Serie    15
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      51     TC
      63     AO
      48     TC
      60     LS
     183     AO
     184     AO
 
Serie    16
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      11     AO
     108     AO
      61     LS
 
Serie    17
   lam= 0   imean= 0   ireg= 4   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     AO
      56     TC
     183     AO
     184     AO
 
Serie    18
   lam= 0   imean= 0   p= 2   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      54     LS
      66     AO
      68     AO
 
Serie    19
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      52     AO
     183     AO
     184     AO
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 312
 
Serie    20
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
     183     AO
     184     AO
     188     AO
      46     AO
      54     AO
 
Serie    21
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      85     LS
     100     TC
      21     AO
     184     AO
     185     AO
     188     AO
 
Serie    22
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      18     AO
      43     AO
 
Serie    23
   lam= 1   imean= 0   p= 1   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
     183     AO
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 312
 
Serie    24
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=263   rsa= 0   modelsumm= 1   va=   3.832
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 348
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 348
 
   Name : NOT DEFINED.
   Reglist03
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      72     AO
      83     LS
     219     AO
     220     AO
     221     AO
     222     AO
 
Serie    25
   lam= 0   d= 0   p= 1   q= 0   ireg= 1   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
Serie    26
   lam= 0   imean= 0   ireg= 3   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     AO
     183     TC
 
Serie    27
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      32     AO
     183     TC
 
Serie    28
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      66     AO
      36     AO
     184     LS
 
Serie    29
   lam= 0   imean= 0   ireg= 2   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 1   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     LS
 
Serie    30
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      66     AO
      36     AO
      14     AO
     145     TC
     181     TC
 
Serie    31
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 1   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      45     LS
 
Serie    32
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     106     AO
     115     TC
      50     AO
      76     AO
     183     TC
     184     AO
     191     TC
 
Serie    33
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 1   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      16     AO
 
Serie    34
   lam= 0   imean= 0   ireg= 8   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     128     AO
      56     AO
      48     LS
       8     AO
     184     AO
     183     LS
     188     AO
 
Serie    35
   lam= 0   imean= 0   ireg= 8   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      56     AO
      44     AO
       8     AO
     128     AO
     184     AO
     183     TC
     188     AO
 
Serie    36
   lam= 0   imean= 0   ireg= 9   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     LS
      56     AO
       8     AO
     128     AO
     184     AO
     185     TC
     188     AO
     183     LS
 
Serie    37
   lam= 0   d= 0   p= 1   q= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      51     LS
     184     TC
     191     AO
     183     TC
 
Serie    38
   lam= 0   imean= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     AO
     183     TC
     191     TC
     188     TC
 
Serie    39
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      51     LS
     184     TC
     183     TC
     191     TC
     186     TC
 
Serie    40
   lam= 0   d= 0   p= 1   q= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      52     TC
      49     TC
      44     LS
      61     LS
     184     AO
     183     TC
 
Serie    41
   lam= 0   imean= 0   q= 2   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      58     TC
      52     TC
     184     AO
     183     TC
 
Serie    42
   lam= 0   imean= 0   ireg=10   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 9   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      51     LS
      61     LS
      49     LS
      56     AO
      20     TC
     184     AO
     183     TC
     185     AO
     188     TC
 
Serie    43
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      56     AO
     184     AO
     183     TC
 
Serie    44
   lam= 0   imean= 0   ireg= 8   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      20     AO
      36     AO
      48     LS
     184     AO
     183     TC
     188     AO
     185     AO
 
Serie    45
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      44     LS
      49     LS
      20     TC
       5     TC
     184     AO
     183     TC
 
Serie    46
   lam= 0   imean= 0   ireg= 5   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      19     TC
      85     LS
      12     AO
     184     LS
 
Serie    47
   lam= 0   imean= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     156     AO
      85     AO
      46     LS
     184     TC
 
Serie    48
   lam= 0   imean= 0   ireg= 6   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      85     TC
     132     TC
      46     LS
      61     LS
     184     LS
 
Serie    49
   lam= 0   imean= 0   ireg= 3   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      19     AO
     184     TC
 
Serie    50
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      15     AO
      12     AO
      39     TC
       7     AO
      54     AO
     183     TC
 
Serie    51
   lam= 0   imean= 0   ireg= 3   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      51     LS
     184     TC
 
Serie    52
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     AO
     183     LS
     186     LS
 
Serie    53
   lam= 0   imean= 0   ireg= 9   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      47     LS
     103     AO
      49     TC
      51     TC
      46     TC
     184     AO
     185     AO
     186     AO
 
Serie    54
   lam= 0   imean= 0   ireg= 5   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     LS
      47     TC
     184     TC
     183     TC
 
Serie    55
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      47     LS
      46     LS
     184     TC
 
Serie    56
   lam= 0   imean= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     122     AO
     165     LS
      63     AO
      75     AO
 
Serie    57
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      11     TC
     184     TC
     171     AO
 
Serie    58
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     165     LS
      70     TC
 
Serie    59
   lam= 0   imean= 0   ireg= 3   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     183     AO
     184     TC
 
Serie    60
   lam= 0   imean= 0   ireg= 6   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      46     LS
      80     AO
     184     AO
     183     TC
 
Serie    61
   lam= 0   imean= 0   ireg= 5   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      12     AO
      48     LS
     184     TC
     183     TC
 
Serie    62
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      56     AO
      37     TC
     109     TC
     184     AO
     183     TC
     185     AO
 
Serie    63
   lam= 0   imean= 0   ireg= 5   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      86     AO
     184     AO
     183     TC
     188     AO
 
Serie    64
   lam= 0   imean= 0   ireg=10   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 9   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      84     AO
      56     AO
      24     AO
      44     LS
     183     AO
     184     AO
     185     AO
     186     AO
 
Serie    65
   lam= 0   imean= 0   ireg= 7   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      56     AO
      48     LS
      51     TC
      46     LS
     184     AO
     181     TC
 
Serie    66
   lam= 0   imean= 0   p= 1   q= 0   ireg= 8   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     LS
      56     AO
      36     AO
     152     AO
      46     LS
     184     AO
     183     TC
 
Serie    67
   lam= 0   imean= 0   q= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      57     LS
     184     AO
 
Serie    68
   lam= 0   imean= 0   ireg= 7   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      24     AO
      52     LS
     184     AO
     183     TC
     185     TC
 
Serie    69
   lam= 0   imean= 0   p= 1   q= 0   ireg= 8   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     LS
      37     LS
      51     TC
      85     LS
      99     AO
     184     AO
     183     TC
 
Serie    70
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      44     AO
      51     AO
      24     AO
     184     AO
     183     TC
 
Serie    71
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 1   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     TC
 
Serie    72
   lam= 0   imean= 0   ireg= 5   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
       3     AO
     108     AO
     130     AO
     184     TC
 
Serie    73
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      21     LS
     184     TC
 
Serie    74
   lam= 0   imean= 0   ireg= 5   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 4   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      26     AO
     184     AO
     183     TC
     180     AO
 
Serie    75
   lam= 0   imean= 0   p= 2   q= 0   ireg= 8   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      38     TC
      56     TC
      60     AO
      49     LS
     184     AO
     183     TC
     187     TC
 
Serie    76
   lam= 0   imean= 0   ireg= 4   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     LS
     184     AO
     183     TC
 
Serie    77
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      50     LS
      57     AO
      56     TC
      44     LS
     184     AO
     183     TC
 
Serie    78
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      66     AO
      68     AO
     126     AO
      47     LS
     184     AO
     183     TC
 
Serie    79
   lam= 0   imean= 0   p= 2   q= 0   ireg= 9   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      54     TC
      49     LS
      58     AO
      43     LS
      56     AO
      42     TC
     184     AO
     183     TC
 
Serie    80
   lam= 0   imean= 0   ireg= 9   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      36     AO
      48     LS
      44     LS
      47     TC
      86     LS
     184     AO
     183     TC
     185     AO
 
Serie    81
   lam= 0   imean= 0   p= 2   q= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      48     TC
      44     AO
     184     AO
     183     TC
     185     TC
     201     AO
 
Serie    82
   lam= 0   imean= 0   ireg= 8   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      47     LS
     105     AO
      44     LS
     184     AO
     183     TC
     185     AO
 
Serie    83
   lam= 0   imean= 0   ireg= 2   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 1   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     AO
 
Serie    84
   lam= 0   imean= 0   p= 2   q= 0   ireg= 9   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      56     TC
      44     AO
      34     AO
      52     LS
     184     AO
     183     TC
     188     AO
 
Serie    85
   lam= 0   imean= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      44     AO
      32     AO
     184     AO
     183     TC
     188     AO
     186     LS
 
Serie    86
   lam= 0   imean= 0   ireg=10   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 9   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      56     AO
      46     AO
      44     LS
      60     LS
     184     AO
     183     TC
     188     AO
     185     AO
 
Serie    87
   lam= 0   imean= 0   ireg=10   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 9   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      56     AO
      29     TC
      16     AO
      13     TC
      11     LS
     184     TC
     185     LS
     187     AO
     183     TC
 
Serie    88
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     156     AO
      56     AO
      44     AO
      30     LS
     184     AO
     183     TC
     188     AO
 
Serie    89
   lam= 0   imean= 0   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     184     TC
     183     TC
     186     TC
 
Serie    90
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 2   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      18     AO
      19     AO
 
Serie    91
   lam= 0   d= 0   p= 2   q= 0   ireg= 7   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      23     TC
      90     LS
      22     AO
      25     AO
      44     TC
      56     TC
 
Serie    92
   lam= 0   imean= 0   q= 2   ireg= 4   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      51     LS
     122     AO
     184     TC
 
Serie    93
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      24     AO
      53     LS
     110     LS
     243     AO
     244     TC
     251     AO
     255     TC
 
Serie    94
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      25     LS
     111     LS
     243     AO
     244     AO
     245     AO
 
Serie    95
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      45     AO
     243     AO
     244     AO
     245     AO
     246     AO
     251     AO
     161     AO
 
Serie    96
   lam= 0   imean= 0   ireg= 3   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser= 3   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     107     LS
     243     LS
     253     AO
 
Serie    97
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      56     AO
     184     AO
     183     TC
     186     LS
 
Serie    98
   lam= 0   imean= 0   ireg=11   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser=10   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      24     AO
      35     AO
      68     AO
      92     TC
      80     AO
     128     AO
     243     AO
     244     AO
     245     AO
     248     AO
 
Serie    99
   lam= 0   imean= 0   ireg= 8   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 7   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     116     AO
      38     LS
     107     LS
       9     TC
     243     AO
     244     AO
     245     AO
 
Serie   100
   lam= 0   imean= 0   ireg= 6   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      49     LS
      44     LS
      56     AO
     184     AO
     183     TC
 
Serie   101
   lam= 0   imean= 0   ireg= 9   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     126     AO
      58     AO
     121     AO
     112     AO
     243     AO
     244     AO
     245     AO
     246     AO
 
Serie   102
   lam= 0   imean= 0   ireg= 6   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 5   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     109     LS
     243     AO
     244     AO
     245     AO
     246     AO
 
Serie   103
   lam= 0   imean= 0   ireg= 7   ieast= 3   seats= 2   iter= 3   int2=227   rsa= 0   modelsumm= 1   va=   3.742
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 312
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      47     LS
      51     TC
      56     AO
      48     LS
     184     TC
     183     TC
 
Serie   104
   lam= 0   imean= 0   p= 1   q= 0   ireg= 7   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 6   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      97     TC
     107     LS
     243     AO
     244     AO
     245     AO
     248     AO
 
Serie   105
   lam= 0   imean= 0   p= 1   q= 0   ireg= 9   seats= 2   iter= 3   int2=287   rsa= 0   modelsumm= 1   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser= 8   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      12     AO
     107     LS
     109     LS
     216     AO
     243     AO
     244     AO
     245     AO
     246     TC
 
