  *** Seats Revision: 942  Build: 2017/09/25 09:48:03                                                            ***
                                   Trend-Cycle Stochastic Component:  
                                       Seasonal frequencies(cycles per year and TD freq.(rad.)
   n   Title                                     --------------------------------------- --------
                                                  one    two    three  four   five   six    TD
   1   "vatasa"                                   --     --     --     --     --     --     -T
   2   "vatasc"                                   --     --     --     --     --     --     -T
   3   "vataia"                                   --     --     --     --     --     --     --
   4   "vatpia"                                   --     --     --     --     --     --     -T
   5   "vatpic"                                   --     --     --     --     --     --     --
   6   "vatpsc"                                   --     --     --     --     --     --     --
   7   "vataic"                                   --     --     --     --     --     --     --
   8   "vatpsa"                                   --     --     --     --     --     --     --
 
 
 
 
 mq=12:  TD= 2.1878 rad 
 mq=4 :  TD= 0.2802 rad 
 
 AT : peaks detected in AR(30) and using Tukey spectrum estimator
 A- : only peaks detected in AR(30) spectrum estimator
 -T : only peaks detected using Tukey estimator spectrum
 -- : No peaks detected in AR(30) nor using Tukey spectrum estimator
