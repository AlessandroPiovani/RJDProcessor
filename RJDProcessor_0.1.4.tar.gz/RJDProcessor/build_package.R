setwd("C:\\Users\\UTENTE\\Desktop\\RJDopenCruncher\\RJDProcessor")

# Assicurati di avere i pacchetti necessari
if (!requireNamespace("devtools", quietly = TRUE)) {
  install.packages("devtools")
}
if (!requireNamespace("roxygen2", quietly = TRUE)) {
  install.packages("roxygen2")
}
# if (!requireNamespace("pkgbuild", quietly = TRUE)) {
#   install.packages("pkgbuild")
# }


# Carica il pacchetto devtools
library(devtools)
library(roxygen2)

#devtools::load_all("R/import_and_interface_definition.R")

# Genera la documentazione
devtools::document()

# Costruisci il pacchetto
devtools::build()

# Controlla il pacchetto
check()

#install.packages("C://Users//UTENTE//Desktop//RJDopenCruncher//RJDProcessor_0.1.4.tar.gz", repos = NULL, type = "source")

