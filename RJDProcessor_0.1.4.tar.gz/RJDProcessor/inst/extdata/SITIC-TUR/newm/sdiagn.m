  *** Seats Revision: 942  Build: 2017/09/25 09:48:03                                                            ***
                                                         Quality diagnostics: Seasonality
 
   n   Title                                                      Not-significant               Highly        Unstable     Ureliable        Revisions  Negligible/
                                                        Last Year  Too many changes  Overall    Stationary   (too large   (estimation err.  too large  Spurious
                                                                   in seas. sign                              innov.var.)   too large)
   1   "vatasa"                                            No            No            No           No            No            No             No          No 
   2   "vatasc"                                            No            No            No           No            No            No             No          No 
   3   "vataia"                                            No            No            No           No            No            No             No          No 
   4   "vatpia"                                            No            No            No           No            No            No             No          No 
   5   "vatpic"                                            No            No            No           No            No            No             No          No 
   6   "vatpsc"                                            No            No            No           No            No            No             No          No 
   7   "vataic"                                            No            No            No           No            No            No             No          No 
   8   "vatpsa"                                            No            No            No           No            No            No             No          No 
