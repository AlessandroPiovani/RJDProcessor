  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
                                                       Stochastic Component: Linealized Series
                                                  Seasonal frequencies(cycles per year and TD freq.(rad.)
                                                 ----------------------------------------------
                                                  one    two    three  four   five   six    TD   
   1   "VATASA"                                   AT     AT     AT     AT     AT     -T     --
   2   "VATASC"                                   AT     AT     AT     AT     AT     at     --
   3   "VATAIA"                                   AT     AT     AT     aT     aT     aT     -t
   4   "VATPIA"                                   AT     AT     AT     aT     AT     AT     --
   5   "VATPIC"                                   AT     AT     AT     -T     AT     AT     --
   6   "VATPSC"                                   AT     AT     AT     AT     AT     a-     --
   7   "VATAIC"                                   AT     AT     AT     AT     aT     AT     --
   8   "VATPSA"                                   AT     AT     AT     AT     AT     -T     --
 
 
 
 
 mq=12:  TD= 2.1878 rad 
 mq=4 :  TD= 0.2802 rad 
 
 AT : peaks detected in AR(30) and using Tukey spectrum estimator
 A- : only peaks detected in AR(30) spectrum estimator
 -T : only peaks detected using Tukey spectrum estimator
 -- : No peaks detected in AR(30) nor using Tukey spectrum estimator
