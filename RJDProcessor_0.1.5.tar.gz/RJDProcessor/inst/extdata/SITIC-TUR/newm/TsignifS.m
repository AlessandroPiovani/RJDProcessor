  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
   n     TITLE                                        QS(Lin) QS(Res) SEAS_NP(Lin)  SEAS_NP(Res) seasPeak(Lin) seasPeak(Res) sigSeas(Lin) sigSeas(Res) FtestSeas(Lin) FtestSeas(Res)
      1  "VATASA"                                       491.5    0.0         229.2         19.20        Y            N            Y             N               -1.         0.6421
      2  "VATASC"                                       519.7    0.0         242.1         13.40        Y            N            Y             N               -1.         0.6703
      3  "VATAIA"                                       409.8    0.0         188.2         7.992        Y            N            Y             N               -1.         0.1148
      4  "VATPIA"                                       508.4   2.10         228.2         4.854        Y            N            Y             N               -1.         0.0449
      5  "VATPIC"                                       508.8  0.094         239.0         16.91        Y            N            Y             N               -1.         0.8643
      6  "VATPSC"                                       520.8    0.0         239.3         15.68        Y            N            Y             N               -1.         0.9447
      7  "VATAIC"                                       468.2    0.0         207.2         9.500        Y            N            Y             N               -1.         0.2744
      8  "VATPSA"                                       502.3  0.005         233.3         13.22        Y            N            Y             N               -1.         0.7099
