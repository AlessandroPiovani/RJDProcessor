  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
                                            REGULAR AR INVERSE ROOTS                              REGULAR MA INVERSE ROOTS
                                                       root(1)           root(2)           root(3)           root(1)           root(2)           root(3)
     n     TITLE                                     mod    per        mod    per        mod    per        mod    per        mod    per        mod    per
     1 "FATEXP_10"                                                                                       0.650    -
     2 "FATEXP_11"                                                                                       0.763    -
     3 "FATEXP_13"                                                                                       0.567    -
     4 "FATEXP_14"                                                                                       0.744    -
     5 "FATEXP_15"                                 0.790    -
     6 "FATEXP_16"                                                                                       0.597    -
     7 "FATEXP_17"                                                                                       0.486    -
     8 "FATEXP_18"                                                                                       0.744    -
     9 "FATEXP_19"                                                                                       0.511    -
    10 "FATEXP_20"                                                                                       0.477    -
    11 "FATEXP_21"                                                                                       0.618    -
    12 "FATEXP_22"                                                                                       0.263    -
    13 "FATEXP_23"                                                                                       0.491    -
    14 "FATEXP_24"                                                                                       0.475    -
    15 "FATEXP_25"                                                                                       0.539    -
    16 "FATEXP_26"                                                                                       0.760    -
    17 "FATEXP_27"                                                                                       0.513    -
    18 "FATEXP_28"                                 0.692    -3.2     0.692     3.2                       0.008    2.0
    19 "FATEXP_29"                                                                                       0.579    -
    20 "FATEXP_31"                                                                                       0.613    -
    21 "FATEXP_32"                                                                                       0.510    -
    22 "FATEXP_33"                                                                                       0.856    -
    23 "FATEXP_C"                                  0.248    2.0                                          0.430    -
    24 "C_DEFL"                                                                                          0.525    -
    25 "DIVIZ08"                                   0.330    -
    26 "DIVID08"                                                                                         0.577    -
    27 "DIVIE08"                                                                                         0.727    -
    28 "DIVIZ10"                                                                                         0.460    -
    29 "DIVID10"                                                                                         0.492    -
    30 "DIVIE10"                                                                                         0.453    -
    31 "DIVIZ11"                                                                                         0.727    -
    32 "DIVID11"                                                                                         0.744    -
    33 "DIVIE11"                                                                                         0.632    -
    34 "DIVIZ13"                                                                                         0.440    -
    35 "DIVID13"                                                                                         0.311    -
    36 "DIVIE13"                                                                                         0.416    -
    37 "DIVIZ14"                                   0.534    -
    38 "DIVID14"                                                                                         0.508    -
    39 "DIVIE14"                                                                                         0.751    -
    40 "DIVIZ15"                                   0.650    -
    41 "DIVID15"                                                                                         0.339    2.0      0.641    -
    42 "DIVIE15"                                                                                         0.319    -
    43 "DIVIZ16"                                                                                         0.443    -
    44 "DIVID16"                                                                                         0.300    -
    45 "DIVIE16"                                                                                         0.611    -
    46 "DIVIZ17"                                                                                         0.243    -
    47 "DIVID17"                                                                                         0.234    -
    48 "DIVIE17"                                                                                         0.221    -
    49 "DIVIZ18"                                                                                         0.549    -
    50 "DIVID18"                                                                                         0.584    -
    51 "DIVIE18"                                                                                         0.476    -
    52 "DIVID19"                                                                                         0.130    -
    53 "DIVIZ20"                                                                                         0.187    -
    54 "DIVID20"                                                                                         0.273    -
    55 "DIVIE20"                                                                                         0.292    -
    56 "DIVIZ21"                                                                                         0.620    -
    57 "DIVID21"                                                                                         0.660    -
    58 "DIVIE21"                                                                                         0.732    -
    59 "DIVIZ22"                                                                                         0.327    -
    60 "DIVID22"                                                                                         0.375    -
    61 "DIVIE22"                                                                                         0.389    -
    62 "DIVIZ23"                                                                                         0.420    -
    63 "DIVID23"                                                                                         0.345    -
    64 "DIVIE23"                                                                                         0.512    -
    65 "DIVIZ24"                                                                                         0.204    -
    66 "DIVID24"                                   0.151    2.0
    67 "DIVIE24"
    68 "DIVIZ25"                                                                                         0.532    -
    69 "DIVID25"                                   0.351    2.0
    70 "DIVIE25"                                                                                         0.474    -
    71 "DIVIZ26"                                                                                         0.699    -
    72 "DIVID26"                                                                                         0.724    -
    73 "DIVIE26"                                                                                         0.696    -
    74 "DIVIZ27"                                                                                         0.312    -
    75 "DIVID27"                                   0.420    -2.6     0.420     2.6
    76 "DIVIE27"                                                                                         0.547    -
    77 "DIVIZ28"                                                                                         0.625    -
    78 "DIVID28"                                                                                         0.591    -
    79 "DIVIE28"                                   0.752    -3.0     0.752     3.0
    80 "DIVIZ29"                                                                                         0.572    -
    81 "DIVID29"                                   0.673    -3.1     0.673     3.1
    82 "DIVIE29"                                                                                         0.616    -
    83 "DIVIZ30"                                                                                         0.906    -
    84 "DIVIZ31"                                   0.644    -3.0     0.644     3.0
    85 "DIVID31"                                                                                         0.538    -
    86 "DIVIE31"                                                                                         0.672    -
    87 "DIVIZ32"                                                                                         0.591    -
    88 "DIVID32"                                                                                         0.631    -
    89 "DIVIE32"                                                                                         0.607    -
    90 "DIVIZ33"                                                                                         0.791    -
    91 "DIVID33"                                   0.687    -        0.714    2.0
    92 "MIGSZ_1"                                                                                         0.341    2.0      0.671    -
    93 "NONDUNAZ"                                                                                        0.583    -
    94 "NONDUEST"                                                                                        0.527    -
    95 "ENERGNAZ"                                                                                        0.124    -
    96 "ENERGEST"                                                                                        0.319    -
    97 "MIGSZ_2"                                                                                         0.575    -
    98 "DUREVNAZ"                                                                                        0.607    -
    99 "DUREVEST"                                                                                        0.649    -
   100 "MIGSZ_3"                                                                                         0.629    -
   101 "INVESNAZ"                                                                                        0.591    -
   102 "INVESEST"                                                                                        0.670    -
   103 "MIGSZ_4"                                                                                         0.275    -
   104 "INTERNAZ"                                  0.215    2.0
   105 "INTEREST"                                  0.363    2.0
