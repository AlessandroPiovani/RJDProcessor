  *** Seats Revision: 942  Build: 2017/09/25 09:48:03                                                            ***
                                   Trend-Cycle Stochastic Component:  
                                       Seasonal frequencies(cycles per year and TD freq.(rad.)
   n   Title                                     --------------------------------------- --------
                                                  one    two    three  four   five   six    TD
   1   "fatexp_10"                                --     --     --     --     --     --     --
   2   "fatexp_11"                                --     --     --     --     --     --     -T
   3   "fatexp_13"                                --     --     --     --     --     --     -t
   4   "fatexp_14"                                --     --     --     --     --     --     --
   5   "fatexp_15"                                --     --     --     --     --     --     --
   6   "fatexp_16"                                --     --     --     --     --     --     --
   7   "fatexp_17"                                --     --     --     --     --     --     -T
   8   "fatexp_18"                                --     --     --     --     --     --     --
   9   "fatexp_19"                                --     --     --     --     --     --     --
  10   "fatexp_20"                                --     --     --     --     --     --     --
  11   "fatexp_21"                                --     --     --     --     --     --     --
  12   "fatexp_22"                                --     --     --     --     --     --     --
  13   "fatexp_23"                                --     --     --     --     --     --     -T
  14   "fatexp_24"                                --     --     --     --     --     --     --
  15   "fatexp_25"                                --     --     --     --     --     --     --
  16   "fatexp_26"                                --     --     --     --     --     --     --
  17   "fatexp_27"                                --     --     --     --     --     --     --
  18   "fatexp_28"                                --     --     --     --     --     --     --
  19   "fatexp_29"                                --     --     --     --     --     --     --
  20   "fatexp_31"                                --     --     --     --     --     --     -t
  21   "fatexp_32"                                --     --     --     --     --     --     -T
  22   "fatexp_33"                                --     --     --     --     --     --     --
  23   "fatexp_c"                                 --     --     --     --     --     --     --
  24   "c_defl"                                   --     --     --     --     --     --     -T
  25   "diviz08"                                  --     --     --     --     --     --     --
  26   "divid08"                                  --     --     --     --     --     --     --
  27   "divie08"                                  --     --     --     --     --     --     --
  28   "diviz10"                                  --     --     --     --     --     --     -T
  29   "divid10"                                  --     --     --     --     --     --     -T
  30   "divie10"                                  --     --     --     --     --     --     --
  31   "diviz11"                                  --     --     --     --     --     --     --
  32   "divid11"                                  --     --     --     --     --     --     -T
  33   "divie11"                                  --     --     --     --     --     --     --
  34   "diviz13"                                  --     --     --     --     --     --     --
  35   "divid13"                                  --     --     --     --     --     --     --
  36   "divie13"                                  --     --     --     --     --     --     -T
  37   "diviz14"                                  --     --     --     --     --     --     -t
  38   "divid14"                                  --     --     --     --     --     --     --
  39   "divie14"                                  --     --     --     --     --     --     -t
  40   "diviz15"                                  --     --     --     --     --     --     -t
  41   "divid15"                                  --     --     --     --     --     --     -t
  42   "divie15"                                  --     --     --     --     --     --     --
  43   "diviz16"                                  --     --     --     --     --     --     -t
  44   "divid16"                                  --     --     --     --     --     --     -t
  45   "divie16"                                  --     --     --     --     --     --     --
  46   "diviz17"                                  --     --     --     --     --     --     -t
  47   "divid17"                                  --     --     --     --     --     --     -T
  48   "divie17"                                  --     --     --     --     --     --     -t
  49   "diviz18"                                  --     --     --     --     --     --     --
  50   "divid18"                                  --     --     --     --     --     --     --
  51   "divie18"                                  --     --     --     --     --     --     --
  52   "divid19"                                  --     --     --     --     --     --     --
  53   "diviz20"                                  --     --     --     --     --     --     -t
  54   "divid20"                                  --     --     --     --     --     --     --
  55   "divie20"                                  --     --     --     --     --     --     --
  56   "diviz21"                                  --     --     --     --     --     --     --
  57   "divid21"                                  --     --     --     --     --     --     --
  58   "divie21"                                  --     --     --     --     --     --     --
  59   "diviz22"                                  --     --     --     --     --     --     --
  60   "divid22"                                  --     --     --     --     --     --     -t
  61   "divie22"                                  --     --     --     --     --     --     --
  62   "diviz23"                                  --     --     --     --     --     --     AT
  63   "divid23"                                  --     --     --     --     --     --     --
  64   "divie23"                                  --     --     --     --     --     --     -T
  65   "diviz24"                                  --     --     --     --     --     --     -t
  66   "divid24"                                  --     --     --     --     --     --     --
  67   "divie24"                                  --     --     --     --     --     --     --
  68   "diviz25"                                  --     --     --     --     --     --     --
  69   "divid25"                                  --     --     --     --     --     --     --
  70   "divie25"                                  --     --     --     --     --     --     --
  71   "diviz26"                                  --     --     --     --     --     --     --
  72   "divid26"                                  --     --     --     --     --     --     --
  73   "divie26"                                  --     --     --     --     --     --     --
  74   "diviz27"                                  --     --     --     --     --     --     --
  75   "divid27"                                  --     --     --     --     --     --     -t
  76   "divie27"                                  --     --     --     --     --     --     -t
  77   "diviz28"                                  --     --     --     --     --     --     -t
  78   "divid28"                                  --     --     --     --     --     --     --
  79   "divie28"                                  --     --     --     --     --     --     --
  80   "diviz29"                                  --     --     --     --     --     --     -t
  81   "divid29"                                  --     a-     --     --     --     --     --
  82   "divie29"                                  --     --     --     --     --     --     -t
  83   "diviz30"                                  --     --     --     --     --     --     --
  84   "diviz31"                                  --     --     --     --     --     --     -T
  85   "divid31"                                  --     --     --     --     --     --     -t
  86   "divie31"                                  --     --     --     --     --     --     -T
  87   "diviz32"                                  --     --     --     --     --     --     --
  88   "divid32"                                  --     --     --     --     --     --     --
  89   "divie32"                                  --     --     --     --     --     --     -t
  90   "diviz33"                                  --     --     --     --     --     --     -t
  91   "divid33"                                  --     --     --     --     --     --     --
  92   "migsz_1"                                  --     --     --     --     --     --     -t
  93   "nondunaz"                                 --     --     --     --     --     --     -T
  94   "nonduest"                                 --     --     --     --     --     --     -t
  95   "energnaz"                                 --     --     --     --     --     --     --
  96   "energest"                                 --     --     --     --     --     --     --
  97   "migsz_2"                                  --     --     --     --     --     --     -t
  98   "durevnaz"                                 --     --     --     --     --     --     --
  99   "durevest"                                 --     --     --     --     --     --     -T
 100   "migsz_3"                                  --     --     --     --     --     --     --
 101   "invesnaz"                                 --     --     --     --     --     --     --
 102   "invesest"                                 --     --     --     --     --     --     --
 103   "migsz_4"                                  --     --     --     --     --     --     --
 104   "internaz"                                 --     --     --     --     --     --     -t
 105   "interest"                                 --     --     --     --     --     --     -T
 
 
 
 
 mq=12:  TD= 2.1878 rad 
 mq=4 :  TD= 0.2802 rad 
 
 AT : peaks detected in AR(30) and using Tukey spectrum estimator
 A- : only peaks detected in AR(30) spectrum estimator
 -T : only peaks detected using Tukey estimator spectrum
 -- : No peaks detected in AR(30) nor using Tukey spectrum estimator
