  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
                                                       Stochastic Component: Original Series
                                                  Seasonal frequencies(cycles per year and TD freq.(rad.)
                                                 ----------------------------------------------
                                                  one    two    three  four   five   six    TD   
   1   "FATEXP_10"                                aT     aT     AT     AT     aT     at     --
   2   "FATEXP_11"                                AT     AT     AT     aT     aT     aT     --
   3   "FATEXP_13"                                aT     AT     AT     aT     AT     aT     --
   4   "FATEXP_14"                                -T     AT     aT     -T     aT     -t     --
   5   "FATEXP_15"                                -T     AT     -T     aT     aT     At     --
   6   "FATEXP_16"                                -T     aT     AT     aT     aT     aT     --
   7   "FATEXP_17"                                -T     at     AT     -T     AT     aT     --
   8   "FATEXP_18"                                AT     AT     -T     --     -T     aT     --
   9   "FATEXP_19"                                --     --     At     --     --     --     --
  10   "FATEXP_20"                                aT     aT     AT     aT     aT     aT     --
  11   "FATEXP_21"                                aT     -T     AT     AT     aT     aT     --
  12   "FATEXP_22"                                --     AT     AT     aT     AT     aT     --
  13   "FATEXP_23"                                -t     aT     AT     aT     AT     aT     --
  14   "FATEXP_24"                                aT     aT     AT     aT     aT     aT     --
  15   "FATEXP_25"                                -t     at     AT     At     AT     AT     --
  16   "FATEXP_26"                                -T     AT     -t     AT     AT     --     --
  17   "FATEXP_27"                                aT     AT     AT     AT     AT     aT     --
  18   "FATEXP_28"                                -t     AT     AT     -t     AT     AT     --
  19   "FATEXP_29"                                -T     AT     --     aT     aT     --     --
  20   "FATEXP_31"                                -t     AT     AT     aT     aT     aT     --
  21   "FATEXP_32"                                AT     AT     -T     aT     aT     -T     --
  22   "FATEXP_33"                                --     --     --     -t     -T     --     --
  23   "FATEXP_C"                                 --     -T     aT     -t     -t     --     a-
  24   "C_DEFL"                                   -t     AT     AT     aT     AT     aT     --
  25   "DIVIZ08"                                  aT     -t     aT     -t     aT     -t     --
  26   "DIVID08"                                  aT     aT     AT     aT     aT     AT     --
  27   "DIVIE08"                                  -T     aT     AT     -T     aT     -t     --
  28   "DIVIZ10"                                  aT     AT     AT     --     -t     aT     aT
  29   "DIVID10"                                  AT     AT     AT     -T     -T     aT     -t
  30   "DIVIE10"                                  AT     AT     AT     --     -T     aT     aT
  31   "DIVIZ11"                                  AT     AT     AT     -T     -T     AT     --
  32   "DIVID11"                                  AT     aT     AT     aT     -T     a-     --
  33   "DIVIE11"                                  AT     AT     AT     -T     aT     AT     -T
  34   "DIVIZ13"                                  aT     AT     AT     aT     aT     aT     --
  35   "DIVID13"                                  aT     AT     AT     AT     AT     aT     --
  36   "DIVIE13"                                  aT     AT     AT     aT     AT     aT     --
  37   "DIVIZ14"                                  aT     AT     AT     aT     -t     aT     --
  38   "DIVID14"                                  aT     AT     AT     aT     aT     AT     --
  39   "DIVIE14"                                  aT     AT     AT     -T     -t     AT     --
  40   "DIVIZ15"                                  --     -T     AT     -T     -T     aT     --
  41   "DIVID15"                                  --     -t     AT     aT     aT     aT     --
  42   "DIVIE15"                                  --     -T     AT     aT     aT     aT     --
  43   "DIVIZ16"                                  -T     AT     AT     aT     aT     aT     --
  44   "DIVID16"                                  -T     AT     AT     aT     AT     aT     --
  45   "DIVIE16"                                  -T     AT     AT     aT     AT     aT     --
  46   "DIVIZ17"                                  aT     aT     AT     -T     -t     AT     -t
  47   "DIVID17"                                  -T     aT     AT     -T     aT     AT     --
  48   "DIVIE17"                                  -T     AT     AT     -T     -T     AT     -t
  49   "DIVIZ18"                                  aT     AT     AT     -t     -t     at     --
  50   "DIVID18"                                  -t     AT     AT     -T     aT     aT     --
  51   "DIVIE18"                                  AT     AT     AT     -t     -T     At     --
  52   "DIVID19"                                  -t     --     at     aT     AT     --     --
  53   "DIVIZ20"                                  -T     aT     AT     aT     aT     aT     --
  54   "DIVID20"                                  aT     AT     AT     aT     aT     AT     --
  55   "DIVIE20"                                  -T     AT     AT     aT     aT     AT     --
  56   "DIVIZ21"                                  -T     AT     AT     -T     aT     AT     --
  57   "DIVID21"                                  AT     AT     AT     AT     AT     aT     --
  58   "DIVIE21"                                  -t     AT     AT     -T     aT     AT     --
  59   "DIVIZ22"                                  aT     aT     AT     aT     aT     aT     --
  60   "DIVID22"                                  -T     AT     AT     aT     AT     aT     --
  61   "DIVIE22"                                  aT     AT     AT     aT     aT     aT     --
  62   "DIVIZ23"                                  aT     aT     AT     -T     aT     AT     --
  63   "DIVID23"                                  -T     aT     AT     aT     AT     AT     --
  64   "DIVIE23"                                  aT     aT     AT     -T     aT     AT     --
  65   "DIVIZ24"                                  aT     aT     AT     aT     aT     aT     --
  66   "DIVID24"                                  aT     aT     AT     aT     AT     AT     --
  67   "DIVIE24"                                  aT     aT     AT     aT     aT     AT     --
  68   "DIVIZ25"                                  -T     aT     AT     -T     aT     AT     --
  69   "DIVID25"                                  -T     AT     AT     AT     AT     AT     --
  70   "DIVIE25"                                  -t     AT     AT     aT     aT     aT     --
  71   "DIVIZ26"                                  -t     AT     aT     AT     aT     a-     --
  72   "DIVID26"                                  AT     AT     aT     AT     AT     -t     --
  73   "DIVIE26"                                  -t     AT     aT     AT     aT     --     --
  74   "DIVIZ27"                                  -t     aT     AT     aT     aT     AT     --
  75   "DIVID27"                                  aT     AT     AT     AT     AT     AT     --
  76   "DIVIE27"                                  --     AT     AT     aT     aT     AT     --
  77   "DIVIZ28"                                  -T     AT     AT     AT     AT     AT     --
  78   "DIVID28"                                  --     AT     AT     AT     AT     aT     --
  79   "DIVIE28"                                  -t     AT     AT     AT     AT     aT     --
  80   "DIVIZ29"                                  -t     -T     AT     aT     -T     aT     --
  81   "DIVID29"                                  -T     aT     AT     AT     AT     aT     --
  82   "DIVIE29"                                  --     -T     AT     aT     -T     aT     --
  83   "DIVIZ30"                                  -T     AT     aT     AT     AT     --     --
  84   "DIVIZ31"                                  -T     aT     AT     aT     AT     aT     --
  85   "DIVID31"                                  -t     aT     AT     aT     AT     aT     --
  86   "DIVIE31"                                  --     aT     AT     aT     AT     aT     --
  87   "DIVIZ32"                                  -t     AT     AT     AT     AT     AT     --
  88   "DIVID32"                                  -t     AT     AT     AT     AT     aT     --
  89   "DIVIE32"                                  --     aT     AT     aT     AT     AT     --
  90   "DIVIZ33"                                  --     At     -t     aT     -T     --     --
  91   "DIVID33"                                  --     AT     aT     AT     AT     --     --
  92   "MIGSZ_1"                                  -T     -T     AT     -T     aT     AT     --
  93   "NONDUNAZ"                                 -t     -T     AT     aT     aT     AT     --
  94   "NONDUEST"                                 -T     aT     AT     -T     aT     AT     --
  95   "ENERGNAZ"                                 -t     --     at     aT     AT     --     --
  96   "ENERGEST"                                 -t     --     --     -T     -t     --     --
  97   "MIGSZ_2"                                  -T     aT     AT     aT     aT     aT     --
  98   "DUREVNAZ"                                 -T     AT     AT     aT     AT     aT     --
  99   "DUREVEST"                                 --     aT     AT     aT     AT     aT     --
 100   "MIGSZ_3"                                  -T     AT     AT     AT     AT     aT     --
 101   "INVESNAZ"                                 -t     AT     AT     AT     AT     aT     --
 102   "INVESEST"                                 -t     AT     AT     AT     AT     aT     --
 103   "MIGSZ_4"                                  aT     aT     AT     aT     aT     aT     --
 104   "INTERNAZ"                                 -T     AT     AT     aT     AT     aT     --
 105   "INTEREST"                                 -T     AT     AT     aT     aT     AT     --
 
 
 
 
 mq=12:  TD= 2.1878 rad 
 mq=4 :  TD= 0.2802 rad 
 
 AT : peaks detected in AR(30) and using Tukey spectrum estimator
 A- : only peaks detected in AR(30) spectrum estimator
 -T : only peaks detected using Tukey spectrum estimator
 -- : No peaks detected in AR(30) nor using Tukey spectrum estimator
