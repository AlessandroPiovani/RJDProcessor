  *** Seats Revision: 942  Build: 2017/09/25 09:48:03                                                            ***
   n   Title                                     Pread.         Approximation                   Model                                     Parameters
                                                        MCS ANA Quality  Ksd  Kqstat   m   p  d  q  bp bd bq    mean     phi(1) phi(2) phi(3)   bphi  th(1)  th(2)  th(3)    bth
   1   "vatasa"                                     Y    N   N     -    1.000  1.000   1   0  1  1   0  1  1   -0.57E-04   0      0      0      0     -0.52   0      0     -0.37
   2   "vatasc"                                     Y    N   N     -    1.000  1.000   1   0  0  2   0  1  1    0.62E-01   0      0      0      0      0.16   0.46   0     -0.22
   3   "vataia"                                     Y    N   N     -    1.000  1.000   1   1  1  1   0  1  0   -0.84E-04   0.20   0      0      0     -0.84   0      0      0   
   4   "vatpia"                                     Y    N   N     -    1.000  1.000   1   0  1  1   0  1  1   -0.10E-03   0      0      0      0     -0.71   0      0     -0.31
   5   "vatpic"                                     Y    N   N     -    1.000  1.000   1   0  1  2   0  1  1   -0.53E-03   0      0      0      0     -0.66  -0.21   0     -0.22
   6   "vatpsc"                                     Y    N   N     -    1.000  1.000   1   2  0  0   0  1  1    0.52E-01  -0.20  -0.23   0      0      0      0      0     -0.19
   7   "vataic"                                     Y    N   N     -    1.000  1.000   1   0  1  1   0  1  0   -0.31E-03   0      0      0      0     -0.93   0      0      0   
   8   "vatpsa"                                     Y    N   N     -    1.000  1.000   1   0  1  1   0  1  1   -0.59E-03   0      0      0      0     -0.26   0      0     -0.50
