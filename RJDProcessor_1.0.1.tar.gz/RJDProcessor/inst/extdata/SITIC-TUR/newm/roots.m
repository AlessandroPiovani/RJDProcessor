  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
                                            REGULAR AR INVERSE ROOTS                              REGULAR MA INVERSE ROOTS
                                                       root(1)           root(2)           root(3)           root(1)           root(2)           root(3)
     n     TITLE                                     mod    per        mod    per        mod    per        mod    per        mod    per        mod    per
     1 "VATASA"                                                                                          0.523    -
     2 "VATASC"                                                                                          0.681    -3.7     0.681     3.7
     3 "VATAIA"                                    0.205    2.0                                          0.842    -
     4 "VATPIA"                                                                                          0.707    -
     5 "VATPIC"                                                                                          0.235    2.0      0.896    -
     6 "VATPSC"                                    0.386    2.0      0.587    -
     7 "VATAIC"                                                                                          0.931    -
     8 "VATPSA"                                                                                          0.261    -
