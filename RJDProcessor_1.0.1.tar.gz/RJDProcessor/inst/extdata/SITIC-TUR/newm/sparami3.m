  *** Seats Revision: 942  Build: 2017/09/25 09:48:03                                                            ***
   n   Title                                              Seasonal Diagnostics: stochastic SA       Signif.Stoch. Season. (95%)  Persistence of Sign in Seas   SA Questionable
                                                        QS          NP         Spec      Overall     Hist.     Prel.     Fore.    # of per.     Chi2Runs
   1   "vatasa"                                        0.00        2.59          N          N        12        12        12            12       243.95                -  
   2   "vatasc"                                        0.00        1.78          N          N        10        12        11            12       253.93                -  
   3   "vataia"                                        0.00        1.40          N          N        11        12        11            12       235.37                -  
   4   "vatpia"                                        0.00        1.37          N          N        12        12        12            12       253.93                -  
   5   "vatpic"                                        0.00        2.18          N          N        12        12        12            12       239.04                -  
   6   "vatpsc"                                        0.00        1.00          N          N        12        12        11            12       250.25                -  
   7   "vataic"                                        0.00        3.67          N          N        12        11        10            12       225.05                -  
   8   "vatpsa"                                        0.00        2.10          N          N        11        12        11            12       253.93                -  
