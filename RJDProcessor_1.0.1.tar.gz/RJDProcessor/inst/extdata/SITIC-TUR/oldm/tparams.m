  *** Tramo Revision: 942  Build: 2017/09/25 09:39:13                                                           ***
   Input Parameters 
Serie     1
   lam= 0   imean= 0   ireg=30   ieast= 3   idur= 3   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser=29   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      22     TC
     242     AO
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     248     AO
     249     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     AO
     258     AO
     259     AO
     260     AO
     261     AO
     262     AO
     263     AO
     264     AO
     265     AO
     266     AO
     267     AO
     268     AO
     269     AO
 
Serie     2
   lam= 0   d= 0   q= 2   ireg=32   ieast= 1   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser=30   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      27     TC
      39     TC
      53     AO
     137     AO
     181     LS
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     186     TC
     184     AO
     101     AO
     248     AO
     249     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     AO
     258     AO
     259     AO
     261     TC
     263     AO
     264     AO
     265     TC
     282     TC
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist03
    Iuser=-1   Nser= 1   Ilong= 372
 
Serie     3
   lam= 0   imean= 0   p= 1   bq= 0   ireg=31   ieast= 3   idur= 3   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 6   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist03
    Iuser= 2   Nser=24   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     185     AO
     143     LS
     242     AO
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     249     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     AO
     263     AO
     265     AO
     266     AO
     267     AO
     270     AO
     276     AO
     282     AO
 
Serie     4
   lam= 0   imean= 0   ireg=27   ieast= 3   idur= 3   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 6   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser=21   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     185     AO
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     AO
     259     AO
     260     AO
     261     AO
     265     AO
     270     AO
     281     AO
     283     AO
 
Serie     5
   lam= 0   imean= 0   q= 2   ireg=20   ieast= 2   idur= 3   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 6   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser=14   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     AO
     265     TC
 
Serie     6
   lam= 0   d= 0   p= 2   q= 0   ireg=27   ieast= 1   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser= 2   Nser=26   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      29     AO
     137     AO
     173     AO
      35     TC
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     248     AO
     249     AO
     250     AO
     221     AO
      53     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     TC
     259     TC
     264     TC
     265     TC
     262     TC
     283     AO
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 372
 
Serie     7
   lam= 0   imean= 0   bq= 0   ireg=23   ieast= 3   idur= 3   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 6   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist03
    Iuser= 2   Nser=16   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
      41     AO
     173     AO
     185     AO
     243     AO
     244     AO
     245     AO
     246     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     269     AO
     277     AO
 
Serie     8
   lam= 0   imean= 0   ireg=29   ieast= 2   seats= 2   iter= 3   int2=287   rsa= 0   bias=-1   units= 0   va=   3.893
 
   Name : NOT DEFINED.
   Reglist01
    Iuser=-1   Nser= 1   Ilong= 372
 
   Name : NOT DEFINED.
   Reglist02
    Iuser= 2   Nser=28   Ilong=   0
 
   Fixed Outliers:
   #Observ. Type
     243     AO
     244     AO
     245     AO
     246     AO
     247     AO
     248     AO
     249     AO
     250     AO
     251     AO
     252     AO
     253     AO
     254     AO
     255     AO
     256     AO
     257     TC
     261     AO
     262     AO
     263     AO
     264     AO
     265     AO
     266     AO
     267     AO
     268     AO
     269     AO
     270     AO
     271     AO
     283     AO
     285     TC
 
